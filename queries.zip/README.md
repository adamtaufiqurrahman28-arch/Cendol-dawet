# CrowdStrike Blue Team CLI

Versi sederhana dan mudah dijalankan.

## Isi folder

- `main.py` → file utama untuk menjalankan aplikasi
- `requirements.txt` → dependency Python
- `.env.example` → template credential CrowdStrike
- `config.py`, `queries.py` → konfigurasi dan preset query
- `services/` → logic Falcon / NGSIEM / RTR
- `ui/` → menu dan tampilan terminal
- `utils/` → helper parsing response

## Cara pakai

### 1. Install dependency
```bash
pip install -r requirements.txt
```

### 2. Buat file `.env`
```bash
cp .env.example .env
```

### 3. Isi credential CrowdStrike di `.env`
```env
FALCON_CLIENT_ID=isi_client_id
FALCON_CLIENT_SECRET=isi_client_secret
FALCON_BASE_URL=
FALCON_DEFAULT_REPOSITORY=search-all
FALCON_DEFAULT_LOOKBACK=1d
FALCON_NGSIEM_POLL_INTERVAL=2
FALCON_NGSIEM_TIMEOUT_SECONDS=60
FALCON_RTR_TIMEOUT_SECONDS=60
FALCON_RTR_QUEUE_OFFLINE=false
```

### 4. Jalankan aplikasi
```bash
python3 main.py
```

Atau:
```bash
python3 main.py --env-file .env
```

## Menu utama

1. Preset Hunting Queries
2. Manual NGSIEM Query
3. Investigation with LLM (dummy)
4. Bulk RTR Put and Run
5. List RTR Cloud Assets
0. Exit

## Catatan

- Preset query encoded PowerShell berasal dari query yang Anda lampirkan.
- Secret lama yang pernah tertulis sebaiknya di-rotate dulu sebelum dipakai lagi.
